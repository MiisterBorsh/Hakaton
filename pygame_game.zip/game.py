import pygame
from menus.main_menu import MainMenu
from levels.forest import ForestLevel
from levels.cave import CaveLevel

class Game:
    def __init__(self, screen):
        self.screen = screen
        self.current_scene = "menu"
        self.main_menu = MainMenu(self)
        self.forest_level = ForestLevel(self)
        self.cave_level = CaveLevel(self)

    def start_level(self):
        self.current_scene = "forest"  # можна змінити на "cave" для іншого рівня

    def start_cave(self):
        self.current_scene = "cave"

    def back_to_menu(self):
        self.current_scene = "menu"

    def handle_event(self, event):
        if self.current_scene == "menu":
            self.main_menu.handle_event(event)
        elif self.current_scene == "forest":
            self.forest_level.handle_event(event)
        elif self.current_scene == "cave":
            self.cave_level.handle_event(event)

    def update(self):
        if self.current_scene == "menu":
            self.main_menu.update()
        elif self.current_scene == "forest":
            self.forest_level.update()
        elif self.current_scene == "cave":
            self.cave_level.update()

    def draw(self):
        if self.current_scene == "menu":
            self.main_menu.draw(self.screen)
        elif self.current_scene == "forest":
            self.forest_level.draw(self.screen)
        elif self.current_scene == "cave":
            self.cave_level.draw(self.screen)
