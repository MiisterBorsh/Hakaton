import pygame
from ui.button import Button
from config import SCREEN_WIDTH, SCREEN_HEIGHT

class MainMenu:
    def __init__(self, game):
        self.game = game
        self.buttons = []
        center_x = SCREEN_WIDTH // 2 - 100
        start_y = 200
        spacing = 70

        self.buttons.append(Button("Ліс", center_x, start_y, 200, 50, self.start_forest))
        self.buttons.append(Button("Печера", center_x, start_y + spacing, 200, 50, self.start_cave))
        self.buttons.append(Button("Налаштування", center_x, start_y + spacing * 2, 200, 50, self.open_settings))
        self.buttons.append(Button("Правила", center_x, start_y + spacing * 3, 200, 50, self.show_rules))
        self.buttons.append(Button("Вихід", center_x, start_y + spacing * 4, 200, 50, self.quit_game))

    def start_forest(self):
        self.game.start_level()

    def start_cave(self):
        self.game.start_cave()

    def open_settings(self):
        print("Налаштування")

    def show_rules(self):
        print("Правила")

    def quit_game(self):
        pygame.quit()
        exit()

    def handle_event(self, event):
        for button in self.buttons:
            button.handle_event(event)

    def update(self):
        mouse_pos = pygame.mouse.get_pos()
        for button in self.buttons:
            button.update(mouse_pos)

    def draw(self, screen):
        screen.fill((100, 100, 255))
        for button in self.buttons:
            button.draw(screen)
