import pygame
from config import DARK_GRAY

class CaveLevel:
    def __init__(self, game):
        self.game = game
        self.font = pygame.font.Font(None, 36)

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.game.back_to_menu()

    def update(self):
        pass

    def draw(self, screen):
        screen.fill(DARK_GRAY)
        text = self.font.render("Ви в Печері! (ESC для виходу)", True, (255, 255, 255))
        screen.blit(text, (50, 50))
