import pygame
from config import GREEN

class ForestLevel:
    def __init__(self, game):
        self.game = game
        self.font = pygame.font.Font(None, 36)

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.game.back_to_menu()

    def update(self):
        pass

    def draw(self, screen):
        screen.fill(GREEN)
        text = self.font.render("Ласкаво просимо до Лісу! (Натисни ESC, щоб вийти)", True, (0, 0, 0))
        screen.blit(text, (50, 50))
