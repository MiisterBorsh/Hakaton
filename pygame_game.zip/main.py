import pygame
import time
from game import Game
from config import SCREEN_WIDTH, SCREEN_HEIGHT, FPS, BLACK

pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Моя гра на Pygame")
clock = pygame.time.Clock()

# Титри на старті
def show_intro():
    font = pygame.font.Font(None, 48)
    text = font.render("[Назва гри] by Zabolotniy Olexandr", True, (255, 255, 255))
    text_rect = text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
    screen.fill(BLACK)
    screen.blit(text, text_rect)
    pygame.display.flip()
    time.sleep(3)

show_intro()

game = Game(screen)

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        game.handle_event(event)

    game.update()
    game.draw()

    pygame.display.flip()
    clock.tick(FPS)

pygame.quit()
